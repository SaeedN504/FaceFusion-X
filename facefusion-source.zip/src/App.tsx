import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { FileUploadZone } from './components/FileUploadZone';
import { ProcessingView } from './components/ProcessingView';
import { ResultView } from './components/ResultView';
import { Button } from './components/ui/Button';
import { Card, CardContent } from './components/ui/Card';
import { Zap, AlertCircle, Info } from 'lucide-react';
import { api, localDemo, isDemoMode } from './lib/supabase';

interface ProcessingJob {
  id: string;
  status: 'pending' | 'uploading' | 'processing' | 'completed' | 'failed';
  progress: number;
  message: string;
  sourceFile: File;
  targetFile: File;
  outputUrl?: string;
  error?: string;
}

function App() {
  const [sourceImage, setSourceImage] = useState<File | null>(null);
  const [targetVideo, setTargetVideo] = useState<File | null>(null);
  const [currentJob, setCurrentJob] = useState<ProcessingJob | null>(null);
  const [resultUrl, setResultUrl] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [demoMode] = useState(isDemoMode());
  
  const handleStartProcessing = async () => {
    if (!sourceImage || !targetVideo) {
      alert('Please upload both a source image and target video.');
      return;
    }
    
    setIsProcessing(true);
    
    const job: ProcessingJob = {
      id: `job_${Date.now()}`,
      status: 'uploading',
      progress: 0,
      message: 'Uploading files...',
      sourceFile: sourceImage,
      targetFile: targetVideo
    };
    
    setCurrentJob(job);
    
    try {
      if (demoMode) {
        // Demo mode simulation
        await simulateProcessing(job);
      } else {
        // Real Supabase processing
        await processWithSupabase(job);
      }
    } catch (error) {
      console.error('Processing error:', error);
      setCurrentJob(prev => prev ? {
        ...prev,
        status: 'failed',
        error: error instanceof Error ? error.message : 'Processing failed'
      } : null);
    }
    
    setIsProcessing(false);
  };
  
  const simulateProcessing = async (job: ProcessingJob) => {
    // Upload simulation
    setCurrentJob(prev => prev ? { ...prev, progress: 20, message: 'Files uploaded successfully...' } : null);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Processing simulation
    setCurrentJob(prev => prev ? { ...prev, status: 'processing', progress: 30, message: 'Initializing face swap engine...' } : null);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setCurrentJob(prev => prev ? { ...prev, progress: 50, message: 'Analyzing source face...' } : null);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setCurrentJob(prev => prev ? { ...prev, progress: 70, message: 'Processing video frames...' } : null);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setCurrentJob(prev => prev ? { ...prev, progress: 90, message: 'Finalizing output video...' } : null);
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Complete
    const outputUrl = URL.createObjectURL(targetVideo);
    setCurrentJob(prev => prev ? { 
      ...prev, 
      status: 'completed', 
      progress: 100, 
      message: 'Face swap completed successfully!',
      outputUrl 
    } : null);
  };
  
  const processWithSupabase = async (job: ProcessingJob) => {
    try {
      // Upload files
      setCurrentJob(prev => prev ? { ...prev, progress: 10, message: 'Uploading source image...' } : null);
      const sourceUrl = await api.uploadFile('source-images', sourceImage!);
      
      setCurrentJob(prev => prev ? { ...prev, progress: 30, message: 'Uploading target video...' } : null);
      const targetUrl = await api.uploadFile('target-videos', targetVideo!);
      
      // Create job
      setCurrentJob(prev => prev ? { ...prev, progress: 40, message: 'Creating processing job...' } : null);
      const jobId = await api.createJob(sourceUrl, targetUrl, sourceImage!, targetVideo!);
      
      // Start processing
      setCurrentJob(prev => prev ? { ...prev, status: 'processing', progress: 50, message: 'Starting face swap processing...' } : null);
      await api.startProcessing(jobId);
      
      // Subscribe to updates
      const subscription = api.subscribeToJob(jobId, (updatedJob) => {
        setCurrentJob(prev => prev ? {
          ...prev,
          status: updatedJob.status,
          progress: updatedJob.progress,
          message: getStatusMessage(updatedJob.status, updatedJob.progress),
          outputUrl: updatedJob.output_video_url,
          error: updatedJob.error_message
        } : null);
      });
      
      // Cleanup subscription on unmount
      return () => subscription.unsubscribe();
    } catch (error) {
      throw error;
    }
  };
  
  const getStatusMessage = (status: string, progress: number): string => {
    switch (status) {
      case 'uploading':
        return 'Uploading files...';
      case 'processing':
        if (progress < 60) return 'Initializing face swap engine...';
        if (progress < 80) return 'Processing video frames...';
        return 'Finalizing output video...';
      case 'completed':
        return 'Face swap completed successfully!';
      case 'failed':
        return 'Processing failed. Please try again.';
      default:
        return 'Preparing...';
    }
  };
  
  const handleJobComplete = (outputUrl: string) => {
    setResultUrl(outputUrl);
  };
  
  const handleStartNew = () => {
    setSourceImage(null);
    setTargetVideo(null);
    setCurrentJob(null);
    setResultUrl('');
    setIsProcessing(false);
  };
  
  const canStartProcessing = sourceImage && targetVideo && !isProcessing;
  
  return (
    <div className="min-h-screen bg-primary-bg">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Demo Mode Banner */}
        {demoMode && (
          <Card className="mb-6 border-amber-500 bg-amber-500 bg-opacity-10">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <Info className="h-5 w-5 text-amber-500 flex-shrink-0" />
                <div className="text-sm">
                  <p className="text-amber-200 font-medium">Demo Mode Active</p>
                  <p className="text-amber-300">
                    You're running in demo mode. To enable real processing, configure your Supabase credentials in the .env file.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Main Content */}
        {!currentJob && !resultUrl && (
          <div className="space-y-8">
            {/* Hero Section */}
            <div className="text-center py-8">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-primary-accent bg-opacity-20 rounded-full mb-6">
                <Zap className="h-10 w-10 text-primary-accent" />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-primary-text mb-4">
                AI-Powered Video
                <span className="text-primary-accent block">Face Swapping</span>
              </h1>
              <p className="text-xl text-primary-text-secondary max-w-2xl mx-auto mb-8">
                Upload your source image and target video to create stunning face swap videos using the powerful Roop engine.
              </p>
            </div>
            
            {/* Upload Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <FileUploadZone
                onFileSelect={setSourceImage}
                acceptedTypes={['image/jpeg', 'image/jpg', 'image/png', 'image/webp']}
                maxSize={50 * 1024 * 1024} // 50MB
                title="Source Face Image"
                description="Upload a clear photo of the face you want to use. JPG, PNG, WEBP up to 50MB."
                currentFile={sourceImage}
                icon="image"
              />
              
              <FileUploadZone
                onFileSelect={setTargetVideo}
                acceptedTypes={['video/mp4', 'video/avi', 'video/mov', 'video/quicktime']}
                maxSize={500 * 1024 * 1024} // 500MB
                title="Target Video"
                description="Upload the video where you want to replace the face. MP4, AVI, MOV up to 500MB."
                currentFile={targetVideo}
                icon="video"
              />
            </div>
            
            {/* Start Processing Button */}
            <div className="text-center py-8">
              <Button
                onClick={handleStartProcessing}
                disabled={!canStartProcessing}
                loading={isProcessing}
                size="lg"
                className="min-w-[200px] text-lg px-8 py-4"
              >
                {isProcessing ? 'Processing...' : 'Start Face Swap'}
              </Button>
              
              {!canStartProcessing && !isProcessing && (
                <p className="text-sm text-primary-text-secondary mt-3">
                  Please upload both a source image and target video to continue.
                </p>
              )}
            </div>
          </div>
        )}
        
        {/* Processing View */}
        {currentJob && !resultUrl && (
          <div className="py-8">
            <ProcessingView 
              job={currentJob} 
              onJobComplete={handleJobComplete}
            />
          </div>
        )}
        
        {/* Result View */}
        {resultUrl && currentJob && (
          <div className="py-8">
            <ResultView
              outputUrl={resultUrl}
              sourceFile={currentJob.sourceFile}
              targetFile={currentJob.targetFile}
              onStartNew={handleStartNew}
            />
          </div>
        )}
      </main>
      
      {/* Footer */}
      <footer className="border-t border-primary-border bg-primary-bg-secondary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-2">
              <Zap className="h-5 w-5 text-primary-accent" />
              <span className="font-semibold text-primary-text">FaceFusion</span>
            </div>
            <p className="text-sm text-primary-text-secondary">
              Powered by the open-source Roop engine. Built with React, TypeScript, and Supabase.
            </p>
            <div className="flex justify-center space-x-6 text-sm">
              <a 
                href="https://github.com/s0md3v/roop" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-primary-text-secondary hover:text-primary-accent transition-colors"
              >
                Roop Engine
              </a>
              <span className="text-primary-border">•</span>
              <a 
                href="#" 
                className="text-primary-text-secondary hover:text-primary-accent transition-colors"
              >
                Privacy Policy
              </a>
              <span className="text-primary-border">•</span>
              <a 
                href="#" 
                className="text-primary-text-secondary hover:text-primary-accent transition-colors"
              >
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;