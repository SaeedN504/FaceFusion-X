import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/Card';
import { Button } from './ui/Button';
import { Download, Play, RotateCcw, Share2, Eye } from 'lucide-react';

interface ResultViewProps {
  outputUrl: string;
  sourceFile: File;
  targetFile: File;
  onStartNew: () => void;
}

export function ResultView({ outputUrl, sourceFile, targetFile, onStartNew }: ResultViewProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showComparison, setShowComparison] = useState(false);
  
  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = outputUrl;
    link.download = `face-swap-${Date.now()}.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Face Swap Result - FaceFusion',
          text: 'Check out my face swap video created with FaceFusion!',
          url: outputUrl
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(outputUrl);
      alert('Link copied to clipboard!');
    }
  };
  
  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Success Header */}
      <Card>
        <CardContent className="p-6 text-center">
          <div className="mb-4">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-success bg-opacity-20 rounded-full mb-4">
              <Eye className="h-8 w-8 text-primary-success" />
            </div>
            <h2 className="text-2xl font-bold text-primary-text mb-2">
              Face Swap Complete! 🎉
            </h2>
            <p className="text-primary-text-secondary">
              Your video has been successfully processed. Preview the result below.
            </p>
          </div>
        </CardContent>
      </Card>
      
      {/* Video Result */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Result Video</span>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowComparison(!showComparison)}
              >
                {showComparison ? 'Hide' : 'Show'} Comparison
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className={`grid ${showComparison ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'} gap-6`}>
            {/* Original Video (only in comparison mode) */}
            {showComparison && (
              <div>
                <h4 className="font-medium text-primary-text mb-3">Original Video</h4>
                <video
                  src={URL.createObjectURL(targetFile)}
                  className="w-full rounded-lg border border-primary-border"
                  controls
                  preload="metadata"
                />
              </div>
            )}
            
            {/* Result Video */}
            <div>
              <h4 className="font-medium text-primary-text mb-3">
                {showComparison ? 'Face Swapped Video' : 'Your Result'}
              </h4>
              <video
                src={outputUrl}
                className="w-full rounded-lg border border-primary-border"
                controls
                preload="metadata"
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
              />
            </div>
          </div>
          
          {/* Action Buttons */}
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Button
              onClick={handleDownload}
              size="lg"
              className="min-w-[140px]"
            >
              <Download className="mr-2 h-5 w-5" />
              Download Video
            </Button>
            
            <Button
              variant="outline"
              onClick={handleShare}
              size="lg"
            >
              <Share2 className="mr-2 h-5 w-5" />
              Share
            </Button>
            
            <Button
              variant="secondary"
              onClick={onStartNew}
              size="lg"
            >
              <RotateCcw className="mr-2 h-5 w-5" />
              Create Another
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* File Information */}
      <Card>
        <CardHeader>
          <CardTitle>Processing Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-primary-bg border border-primary-border rounded-lg p-4">
              <h4 className="font-medium text-primary-text mb-2">Source Face</h4>
              <div className="flex items-center space-x-3">
                <img
                  src={URL.createObjectURL(sourceFile)}
                  alt="Source face"
                  className="w-12 h-12 object-cover rounded border border-primary-border"
                />
                <div>
                  <p className="text-sm font-medium text-primary-text truncate max-w-[120px]">
                    {sourceFile.name}
                  </p>
                  <p className="text-xs text-primary-text-secondary">
                    {(sourceFile.size / 1024 / 1024).toFixed(1)} MB
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-primary-bg border border-primary-border rounded-lg p-4">
              <h4 className="font-medium text-primary-text mb-2">Target Video</h4>
              <div className="flex items-center space-x-3">
                <video
                  src={URL.createObjectURL(targetFile)}
                  className="w-12 h-12 object-cover rounded border border-primary-border"
                  muted
                  preload="metadata"
                />
                <div>
                  <p className="text-sm font-medium text-primary-text truncate max-w-[120px]">
                    {targetFile.name}
                  </p>
                  <p className="text-xs text-primary-text-secondary">
                    {(targetFile.size / 1024 / 1024).toFixed(1)} MB
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-primary-bg border border-primary-border rounded-lg p-4">
              <h4 className="font-medium text-primary-text mb-2">Result</h4>
              <div className="text-center">
                <Play className="h-12 w-12 text-primary-accent mx-auto mb-2" />
                <p className="text-sm font-medium text-primary-text">
                  Face Swapped Video
                </p>
                <p className="text-xs text-primary-text-secondary">
                  MP4 Format
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}