import React from 'react';

interface ProgressBarProps {
  progress: number; // 0 to 100
  status?: string;
  showPercentage?: boolean;
  className?: string;
}

export function ProgressBar({ 
  progress, 
  status, 
  showPercentage = true, 
  className = '' 
}: ProgressBarProps) {
  const clampedProgress = Math.max(0, Math.min(100, progress));
  
  return (
    <div className={`w-full ${className}`}>
      {(status || showPercentage) && (
        <div className="flex justify-between items-center mb-2">
          {status && (
            <span className="text-sm text-primary-text-secondary">{status}</span>
          )}
          {showPercentage && (
            <span className="text-sm font-medium text-primary-text">
              {Math.round(clampedProgress)}%
            </span>
          )}
        </div>
      )}
      <div className="w-full bg-primary-bg-secondary rounded-full h-3 border border-primary-border overflow-hidden">
        <div 
          className="h-full bg-gradient-to-r from-primary-accent-hover to-primary-accent transition-all duration-300 ease-out progress-bar"
          style={{ width: `${clampedProgress}%` }}
        >
          <div className="h-full w-full bg-gradient-to-r from-transparent via-white to-transparent opacity-20 animate-pulse"></div>
        </div>
      </div>
    </div>
  );
}