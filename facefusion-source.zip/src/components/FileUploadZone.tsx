import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, X, File, Image, Video } from 'lucide-react';
import { Card, CardContent } from './ui/Card';
import { Button } from './ui/Button';

interface FileUploadZoneProps {
  onFileSelect: (file: File) => void;
  acceptedTypes: string[];
  maxSize: number;
  title: string;
  description: string;
  currentFile?: File | null;
  icon?: 'image' | 'video';
}

export function FileUploadZone({
  onFileSelect,
  acceptedTypes,
  maxSize,
  title,
  description,
  currentFile,
  icon = 'image'
}: FileUploadZoneProps) {
  const [error, setError] = useState<string>('');
  
  const onDrop = useCallback((acceptedFiles: File[]) => {
    setError('');
    
    if (acceptedFiles.length === 0) {
      setError('Invalid file type. Please check the accepted formats.');
      return;
    }
    
    const file = acceptedFiles[0];
    
    if (file.size > maxSize) {
      setError(`File size exceeds ${Math.round(maxSize / 1024 / 1024)}MB limit.`);
      return;
    }
    
    onFileSelect(file);
  }, [onFileSelect, maxSize]);
  
  const onDropRejected = useCallback(() => {
    setError('Invalid file type or size. Please check the requirements.');
  }, []);
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    onDropRejected,
    accept: acceptedTypes.reduce((acc, type) => {
      acc[type] = [];
      return acc;
    }, {} as Record<string, string[]>),
    maxSize,
    multiple: false
  });
  
  const handleRemoveFile = () => {
    onFileSelect(null as any);
    setError('');
  };
  
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };
  
  const IconComponent = icon === 'video' ? Video : Image;
  
  return (
    <Card className="h-full">
      <CardContent className="p-6 h-full">
        <div className="h-full flex flex-col">
          <h3 className="text-lg font-semibold text-primary-text mb-2">{title}</h3>
          <p className="text-sm text-primary-text-secondary mb-4">{description}</p>
          
          {!currentFile ? (
            <div
              {...getRootProps()}
              className={`
                flex-1 border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all duration-200
                ${isDragActive ? 'drag-over' : 'border-primary-border hover:border-primary-accent'}
                ${error ? 'border-primary-error' : ''}
              `}
            >
              <input {...getInputProps()} />
              <div className="flex flex-col items-center justify-center h-full min-h-[200px]">
                {isDragActive ? (
                  <Upload className="h-12 w-12 text-primary-accent mb-4 animate-pulse" />
                ) : (
                  <IconComponent className="h-12 w-12 text-primary-text-secondary mb-4" />
                )}
                <p className="text-lg font-medium text-primary-text mb-2">
                  {isDragActive ? 'Drop your file here' : 'Drag & drop your file here'}
                </p>
                <p className="text-sm text-primary-text-secondary mb-4">
                  or click to browse
                </p>
                <div className="text-xs text-primary-text-secondary">
                  <p>Accepted formats: {acceptedTypes.map(type => type.split('/')[1]).join(', ').toUpperCase()}</p>
                  <p>Max size: {Math.round(maxSize / 1024 / 1024)}MB</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 border border-primary-border rounded-lg p-6 bg-primary-bg">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <IconComponent className="h-8 w-8 text-primary-accent" />
                  <div>
                    <p className="font-medium text-primary-text truncate max-w-[200px]">
                      {currentFile.name}
                    </p>
                    <p className="text-sm text-primary-text-secondary">
                      {formatFileSize(currentFile.size)}
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleRemoveFile}
                  className="text-primary-error hover:text-primary-error hover:bg-primary-error hover:bg-opacity-10"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              {currentFile.type.startsWith('image/') && (
                <div className="mt-4">
                  <img
                    src={URL.createObjectURL(currentFile)}
                    alt="Preview"
                    className="w-full h-32 object-cover rounded border border-primary-border"
                  />
                </div>
              )}
              
              {currentFile.type.startsWith('video/') && (
                <div className="mt-4">
                  <video
                    src={URL.createObjectURL(currentFile)}
                    className="w-full h-32 object-cover rounded border border-primary-border"
                    controls={false}
                    muted
                    preload="metadata"
                  />
                  <p className="text-xs text-primary-text-secondary mt-2 text-center">
                    Video preview - Click "Start Face Swap" to begin processing
                  </p>
                </div>
              )}
            </div>
          )}
          
          {error && (
            <div className="mt-4 p-3 bg-primary-error bg-opacity-10 border border-primary-error rounded-lg">
              <p className="text-sm text-primary-error">{error}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}