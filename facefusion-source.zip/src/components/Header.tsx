import React from 'react';
import { Zap, Github, HelpCircle } from 'lucide-react';
import { Button } from './ui/Button';

export function Header() {
  return (
    <header className="border-b border-primary-border bg-primary-bg backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Zap className="h-8 w-8 text-primary-accent" />
              <div className="absolute inset-0 h-8 w-8 text-primary-accent animate-pulse opacity-20">
                <Zap className="h-8 w-8" />
              </div>
            </div>
            <div>
              <h1 className="text-xl font-bold text-primary-text">
                Face<span className="text-primary-accent">Fusion</span>
              </h1>
              <p className="text-xs text-primary-text-secondary -mt-1">
                Open Source Video Face Swap
              </p>
            </div>
          </div>
          
          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.open('https://github.com/s0md3v/roop', '_blank')}
            >
              <Github className="mr-2 h-4 w-4" />
              Roop Engine
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                const modal = document.getElementById('help-modal');
                if (modal) modal.style.display = 'block';
              }}
            >
              <HelpCircle className="mr-2 h-4 w-4" />
              How it Works
            </Button>
          </nav>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button variant="ghost" size="sm">
              <HelpCircle className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Help Modal */}
      <div id="help-modal" className="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div className="bg-primary-bg-secondary border border-primary-border rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto">
          <div className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-primary-text">How FaceFusion Works</h2>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  const modal = document.getElementById('help-modal');
                  if (modal) modal.style.display = 'none';
                }}
              >
                ×
              </Button>
            </div>
            
            <div className="space-y-4 text-primary-text">
              <div>
                <h3 className="font-semibold text-primary-accent mb-2">What is Face Swapping?</h3>
                <p className="text-sm text-primary-text-secondary">
                  Face swapping uses AI to replace faces in videos with another person's face while maintaining natural expressions and movements.
                </p>
              </div>
              
              <div>
                <h3 className="font-semibold text-primary-accent mb-2">How to Use FaceFusion</h3>
                <ol className="text-sm text-primary-text-secondary space-y-1 list-decimal list-inside">
                  <li>Upload a clear photo of the face you want to use (source image)</li>
                  <li>Upload the video where you want to replace the face (target video)</li>
                  <li>Click "Start Face Swap" and wait for processing</li>
                  <li>Download your result video when complete</li>
                </ol>
              </div>
              
              <div>
                <h3 className="font-semibold text-primary-accent mb-2">Tips for Best Results</h3>
                <ul className="text-sm text-primary-text-secondary space-y-1 list-disc list-inside">
                  <li>Use high-quality, well-lit photos for the source face</li>
                  <li>Ensure the face in the source image is clearly visible</li>
                  <li>Target videos with clear, front-facing subjects work best</li>
                  <li>Processing time depends on video length and quality</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-semibold text-primary-accent mb-2">Powered by Roop</h3>
                <p className="text-sm text-primary-text-secondary">
                  FaceFusion uses the open-source Roop engine, a cutting-edge face swapping technology. 
                  All processing happens securely, and your files are automatically cleaned up after processing.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}