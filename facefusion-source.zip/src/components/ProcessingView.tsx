import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/Card';
import { ProgressBar } from './ui/ProgressBar';
import { Spinner } from './ui/Spinner';
import { CheckCircle, XCircle, Clock, Cpu } from 'lucide-react';

interface ProcessingJob {
  id: string;
  status: 'pending' | 'uploading' | 'processing' | 'completed' | 'failed';
  progress: number;
  message: string;
  sourceFile: File;
  targetFile: File;
  outputUrl?: string;
  error?: string;
}

interface ProcessingViewProps {
  job: ProcessingJob;
  onJobComplete: (outputUrl: string) => void;
}

export function ProcessingView({ job, onJobComplete }: ProcessingViewProps) {
  const [timeElapsed, setTimeElapsed] = useState(0);
  
  useEffect(() => {
    if (job.status === 'processing' || job.status === 'uploading') {
      const interval = setInterval(() => {
        setTimeElapsed(prev => prev + 1);
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [job.status]);
  
  useEffect(() => {
    if (job.status === 'completed' && job.outputUrl) {
      onJobComplete(job.outputUrl);
    }
  }, [job.status, job.outputUrl, onJobComplete]);
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  const getStatusIcon = () => {
    switch (job.status) {
      case 'uploading':
      case 'processing':
        return <Spinner size="lg" />;
      case 'completed':
        return <CheckCircle className="h-12 w-12 text-primary-success" />;
      case 'failed':
        return <XCircle className="h-12 w-12 text-primary-error" />;
      default:
        return <Clock className="h-12 w-12 text-primary-text-secondary" />;
    }
  };
  
  const getStatusColor = () => {
    switch (job.status) {
      case 'completed':
        return 'text-primary-success';
      case 'failed':
        return 'text-primary-error';
      case 'processing':
      case 'uploading':
        return 'text-primary-accent';
      default:
        return 'text-primary-text-secondary';
    }
  };
  
  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center space-x-3">
          <Cpu className="h-6 w-6 text-primary-accent" />
          <span>Face Swap Processing</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Status Icon */}
          <div className="flex justify-center py-8">
            {getStatusIcon()}
          </div>
          
          {/* Status Message */}
          <div className="text-center">
            <h3 className={`text-xl font-semibold ${getStatusColor()}`}>
              {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
            </h3>
            <p className="text-primary-text-secondary mt-2">
              {job.message}
            </p>
          </div>
          
          {/* Progress Bar */}
          {(job.status === 'uploading' || job.status === 'processing') && (
            <ProgressBar 
              progress={job.progress}
              status={job.message}
              className="py-4"
            />
          )}
          
          {/* File Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-primary-bg border border-primary-border rounded-lg p-4">
              <h4 className="font-medium text-primary-text mb-2">Source Face</h4>
              <div className="flex items-center space-x-3">
                <img
                  src={URL.createObjectURL(job.sourceFile)}
                  alt="Source face"
                  className="w-12 h-12 object-cover rounded border border-primary-border"
                />
                <div>
                  <p className="text-sm font-medium text-primary-text truncate max-w-[120px]">
                    {job.sourceFile.name}
                  </p>
                  <p className="text-xs text-primary-text-secondary">
                    {(job.sourceFile.size / 1024 / 1024).toFixed(1)} MB
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-primary-bg border border-primary-border rounded-lg p-4">
              <h4 className="font-medium text-primary-text mb-2">Target Video</h4>
              <div className="flex items-center space-x-3">
                <video
                  src={URL.createObjectURL(job.targetFile)}
                  className="w-12 h-12 object-cover rounded border border-primary-border"
                  muted
                  preload="metadata"
                />
                <div>
                  <p className="text-sm font-medium text-primary-text truncate max-w-[120px]">
                    {job.targetFile.name}
                  </p>
                  <p className="text-xs text-primary-text-secondary">
                    {(job.targetFile.size / 1024 / 1024).toFixed(1)} MB
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Time Elapsed */}
          {(job.status === 'processing' || job.status === 'uploading') && (
            <div className="text-center">
              <p className="text-sm text-primary-text-secondary">
                Time elapsed: <span className="font-mono">{formatTime(timeElapsed)}</span>
              </p>
            </div>
          )}
          
          {/* Error Message */}
          {job.status === 'failed' && job.error && (
            <div className="bg-primary-error bg-opacity-10 border border-primary-error rounded-lg p-4">
              <p className="text-sm text-primary-error">
                <strong>Error:</strong> {job.error}
              </p>
            </div>
          )}
          
          {/* Processing Steps */}
          {job.status === 'processing' && (
            <div className="bg-primary-bg-secondary border border-primary-border rounded-lg p-4">
              <h4 className="font-medium text-primary-text mb-3">Processing Steps</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-primary-success" />
                  <span className="text-primary-text">Files uploaded</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-primary-success" />
                  <span className="text-primary-text">Roop engine initialized</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Spinner size="sm" />
                  <span className="text-primary-text">Swapping faces...</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-primary-text-secondary" />
                  <span className="text-primary-text-secondary">Finalizing video</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}