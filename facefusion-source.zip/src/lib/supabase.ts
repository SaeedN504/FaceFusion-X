import { createClient } from '@supabase/supabase-js'

// Supabase configuration
// Note: Replace these with your actual Supabase project credentials
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://your-project.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'your-anon-key'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export interface FaceSwapJob {
  id: string
  user_id?: string
  source_image_url: string
  target_video_url: string
  output_video_url?: string
  status: 'pending' | 'uploading' | 'processing' | 'completed' | 'failed'
  progress: number
  error_message?: string
  source_file_name: string
  target_file_name: string
  output_file_name?: string
  source_file_size: number
  target_file_size: number
  output_file_size?: number
  processing_started_at?: string
  processing_completed_at?: string
  created_at: string
  updated_at: string
}

export interface ProcessingLog {
  id: string
  job_id: string
  log_level: 'info' | 'warning' | 'error'
  message: string
  details?: any
  created_at: string
}

// API functions
export const api = {
  // Upload file to Supabase Storage
  async uploadFile(bucket: string, file: File, path?: string): Promise<string> {
    const fileName = path || `${Date.now()}-${file.name}`
    
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false
      })
    
    if (error) {
      console.error('Upload error:', error)
      throw new Error(`Upload failed: ${error.message}`)
    }
    
    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from(bucket)
      .getPublicUrl(data.path)
    
    return publicUrl
  },
  
  // Create a new face swap job
  async createJob(sourceImageUrl: string, targetVideoUrl: string, sourceFile: File, targetFile: File): Promise<string> {
    const { data, error } = await supabase
      .from('face_swap_jobs')
      .insert({
        source_image_url: sourceImageUrl,
        target_video_url: targetVideoUrl,
        source_file_name: sourceFile.name,
        target_file_name: targetFile.name,
        source_file_size: sourceFile.size,
        target_file_size: targetFile.size,
        status: 'pending',
        progress: 0
      })
      .select()
      .single()
    
    if (error) {
      console.error('Job creation error:', error)
      throw new Error(`Failed to create job: ${error.message}`)
    }
    
    return data.id
  },
  
  // Get job status
  async getJob(jobId: string): Promise<FaceSwapJob | null> {
    const { data, error } = await supabase
      .from('face_swap_jobs')
      .select('*')
      .eq('id', jobId)
      .single()
    
    if (error) {
      console.error('Job fetch error:', error)
      return null
    }
    
    return data
  },
  
  // Subscribe to job updates
  subscribeToJob(jobId: string, callback: (job: FaceSwapJob) => void) {
    return supabase
      .channel(`job_${jobId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'face_swap_jobs',
          filter: `id=eq.${jobId}`
        },
        (payload) => {
          callback(payload.new as FaceSwapJob)
        }
      )
      .subscribe()
  },
  
  // Start processing job (calls Edge Function)
  async startProcessing(jobId: string): Promise<void> {
    const { error } = await supabase.functions.invoke('process-face-swap', {
      body: { jobId }
    })
    
    if (error) {
      console.error('Processing start error:', error)
      throw new Error(`Failed to start processing: ${error.message}`)
    }
  }
}

// Local storage for demo mode
export const localDemo = {
  // Simulate file upload for demo
  async uploadFile(file: File): Promise<string> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const url = URL.createObjectURL(file)
        resolve(url)
      }, 1000)
    })
  },
  
  // Simulate job processing for demo
  async processJob(sourceFile: File, targetFile: File): Promise<{ jobId: string; outputUrl: string }> {
    const jobId = `demo_${Date.now()}`
    
    // Return a demo output URL (same as target for demo purposes)
    const outputUrl = URL.createObjectURL(targetFile)
    
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({ jobId, outputUrl })
      }, 5000) // 5 second demo processing
    })
  }
}

// Check if we're in demo mode (no Supabase connection)
export const isDemoMode = (): boolean => {
  return supabaseUrl.includes('your-project') || supabaseAnonKey.includes('your-anon-key')
}