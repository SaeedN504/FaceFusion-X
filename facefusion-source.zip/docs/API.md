# FaceFusion API Documentation

This document describes the API endpoints and database schema for the FaceFusion application.

## 🔧 Edge Functions

### process-face-swap

Starts the face swapping process for a given job.

**Endpoint:** `POST /functions/v1/process-face-swap`

**Headers:**
```
Content-Type: application/json
Authorization: Bearer <supabase-anon-key>
```

**Request Body:**
```json
{
  "jobId": "uuid-string"
}
```

**Response:**
```json
{
  "data": {
    "jobId": "uuid-string",
    "status": "processing",
    "message": "Face swap processing started"
  }
}
```

**Error Response:**
```json
{
  "error": {
    "code": "FACE_SWAP_FAILED",
    "message": "Error description"
  }
}
```

## 📊 Database Schema

### face_swap_jobs

Main table for tracking face swap processing jobs.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key |
| user_id | UUID | User identifier (nullable for anonymous users) |
| source_image_url | TEXT | URL to source face image |
| target_video_url | TEXT | URL to target video |
| output_video_url | TEXT | URL to processed result video |
| status | TEXT | Job status: 'pending', 'uploading', 'processing', 'completed', 'failed' |
| progress | INTEGER | Processing progress (0-100) |
| error_message | TEXT | Error details if job failed |
| source_file_name | TEXT | Original source file name |
| target_file_name | TEXT | Original target file name |
| output_file_name | TEXT | Generated output file name |
| source_file_size | BIGINT | Source file size in bytes |
| target_file_size | BIGINT | Target file size in bytes |
| output_file_size | BIGINT | Output file size in bytes |
| processing_started_at | TIMESTAMP | When processing began |
| processing_completed_at | TIMESTAMP | When processing finished |
| created_at | TIMESTAMP | Record creation time |
| updated_at | TIMESTAMP | Last update time |

### processing_logs

Detailed logs for debugging and monitoring.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key |
| job_id | UUID | Reference to face_swap_jobs.id |
| log_level | TEXT | Log level: 'info', 'warning', 'error', 'debug' |
| message | TEXT | Log message |
| details | JSONB | Additional structured data |
| created_at | TIMESTAMP | Log entry creation time |

### user_profiles

User information and statistics.

| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Primary key (matches auth.users.id) |
| email | TEXT | User email |
| full_name | TEXT | User full name |
| avatar_url | TEXT | Profile picture URL |
| total_jobs | INTEGER | Total jobs created |
| successful_jobs | INTEGER | Successfully completed jobs |
| failed_jobs | INTEGER | Failed jobs |
| created_at | TIMESTAMP | Profile creation time |
| updated_at | TIMESTAMP | Last profile update |

## 🛡️ Storage Buckets

### source-images
- **Purpose:** Store uploaded face images
- **Access:** Public read
- **Max size:** 50MB per file
- **Allowed types:** JPG, PNG, WEBP

### target-videos
- **Purpose:** Store uploaded target videos
- **Access:** Public read
- **Max size:** 500MB per file
- **Allowed types:** MP4, AVI, MOV

### output-videos
- **Purpose:** Store processed result videos
- **Access:** Public read
- **Max size:** 500MB per file
- **Allowed types:** MP4

## 🔒 Security

### Row Level Security (RLS)

All tables have RLS enabled with the following policies:

**face_swap_jobs:**
- Users can view their own jobs or anonymous jobs
- Users can create new jobs
- Users can update their own jobs
- Users can delete their own jobs

**processing_logs:**
- Users can view logs for their own jobs
- System can insert logs for any job

**user_profiles:**
- Users can only access their own profile

### File Security

- File uploads are validated for type and size
- Temporary files are automatically cleaned up
- All file operations are logged

## 🗺️ API Workflow

### Complete Face Swap Process

1. **Upload Files**
   ```javascript
   const sourceUrl = await api.uploadFile('source-images', sourceFile)
   const targetUrl = await api.uploadFile('target-videos', targetFile)
   ```

2. **Create Job**
   ```javascript
   const jobId = await api.createJob(sourceUrl, targetUrl, sourceFile, targetFile)
   ```

3. **Start Processing**
   ```javascript
   await api.startProcessing(jobId)
   ```

4. **Monitor Progress**
   ```javascript
   const subscription = api.subscribeToJob(jobId, (job) => {
     console.log(`Progress: ${job.progress}%, Status: ${job.status}`)
   })
   ```

5. **Get Result**
   ```javascript
   if (job.status === 'completed') {
     const resultUrl = job.output_video_url
     // Download or display result
   }
   ```

## 🔍 Real-time Updates

### Supabase Realtime

The application uses Supabase Realtime to provide live updates:

```javascript
const subscription = supabase
  .channel(`job_${jobId}`)
  .on(
    'postgres_changes',
    {
      event: 'UPDATE',
      schema: 'public',
      table: 'face_swap_jobs',
      filter: `id=eq.${jobId}`
    },
    (payload) => {
      updateUI(payload.new)
    }
  )
  .subscribe()
```

## ⚡ Performance Considerations

### File Uploads
- Use chunked uploads for large files
- Implement upload progress tracking
- Validate files client-side before upload

### Processing
- Jobs are processed asynchronously
- Progress updates are sent via Realtime
- Failed jobs include detailed error messages

### Database
- Indexes on frequently queried columns
- Automatic cleanup of old jobs
- Efficient queries using proper filtering

## 🕰️ Rate Limiting

For production use, consider implementing:

- User-based processing quotas
- File size limits per user
- Concurrent processing limits
- API rate limiting

## 📊 Monitoring

### Logs
- All processing steps are logged
- Error tracking with stack traces
- Performance metrics collection

### Metrics
- Job completion rates
- Processing times
- Error frequencies
- Storage usage

### Alerts
- Failed job notifications
- Storage quota warnings
- Performance degradation alerts

## 🤝 Integration Examples

### React Hook

```typescript
export function useFaceSwap() {
  const createJob = useMutation({
    mutationFn: async ({ sourceFile, targetFile }: {
      sourceFile: File
      targetFile: File
    }) => {
      const sourceUrl = await api.uploadFile('source-images', sourceFile)
      const targetUrl = await api.uploadFile('target-videos', targetFile)
      const jobId = await api.createJob(sourceUrl, targetUrl, sourceFile, targetFile)
      await api.startProcessing(jobId)
      return jobId
    }
  })
  
  return { createJob }
}
```

### Progress Tracking

```typescript
export function useJobProgress(jobId: string) {
  const [job, setJob] = useState<FaceSwapJob | null>(null)
  
  useEffect(() => {
    if (!jobId) return
    
    const subscription = api.subscribeToJob(jobId, setJob)
    return () => subscription.unsubscribe()
  }, [jobId])
  
  return job
}
```

This API provides a complete foundation for building face swap applications with real-time progress tracking and secure file handling.