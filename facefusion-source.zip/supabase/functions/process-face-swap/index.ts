// Supabase Edge Function for Face Swap Processing using Roop
// This function handles the integration with the Roop face swap engine

Deno.serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { jobId } = await req.json();

    if (!jobId) {
      throw new Error('Job ID is required');
    }

    // Get environment variables
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    const supabaseUrl = Deno.env.get('SUPABASE_URL');

    if (!serviceRoleKey || !supabaseUrl) {
      throw new Error('Supabase configuration missing');
    }

    console.log(`Starting face swap processing for job: ${jobId}`);

    // Get job details from database
    const jobResponse = await fetch(`${supabaseUrl}/rest/v1/face_swap_jobs?id=eq.${jobId}`, {
      headers: {
        'Authorization': `Bearer ${serviceRoleKey}`,
        'apikey': serviceRoleKey,
        'Content-Type': 'application/json'
      }
    });

    if (!jobResponse.ok) {
      throw new Error('Failed to fetch job details');
    }

    const jobs = await jobResponse.json();
    if (jobs.length === 0) {
      throw new Error('Job not found');
    }

    const job = jobs[0];

    // Update job status to processing
    await updateJobStatus(jobId, 'processing', 10, 'Initializing face swap engine...', serviceRoleKey, supabaseUrl);

    // Download source image and target video
    console.log('Downloading source image and target video...');
    await updateJobStatus(jobId, 'processing', 20, 'Downloading files...', serviceRoleKey, supabaseUrl);
    
    const sourceImagePath = await downloadFile(job.source_image_url, `source_${jobId}.jpg`);
    const targetVideoPath = await downloadFile(job.target_video_url, `target_${jobId}.mp4`);

    // Process with Roop
    await updateJobStatus(jobId, 'processing', 30, 'Starting face swap processing...', serviceRoleKey, supabaseUrl);
    
    const outputPath = `output_${jobId}.mp4`;
    
    try {
      await processWithRoop(sourceImagePath, targetVideoPath, outputPath, jobId, serviceRoleKey, supabaseUrl);
    } catch (error) {
      console.error('Roop processing failed:', error);
      await updateJobStatus(jobId, 'failed', 0, 'Face swap processing failed', serviceRoleKey, supabaseUrl, error.message);
      throw error;
    }

    // Upload result to Supabase Storage
    await updateJobStatus(jobId, 'processing', 90, 'Uploading result video...', serviceRoleKey, supabaseUrl);
    
    const outputUrl = await uploadResultVideo(outputPath, jobId, serviceRoleKey, supabaseUrl);

    // Complete job
    await updateJobStatus(jobId, 'completed', 100, 'Face swap completed successfully!', serviceRoleKey, supabaseUrl);
    
    // Update job with output URL
    await fetch(`${supabaseUrl}/rest/v1/face_swap_jobs?id=eq.${jobId}`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${serviceRoleKey}`,
        'apikey': serviceRoleKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        output_video_url: outputUrl,
        processing_completed_at: new Date().toISOString()
      })
    });

    // Cleanup temporary files
    await cleanupTempFiles([sourceImagePath, targetVideoPath, outputPath]);

    console.log(`Face swap processing completed for job: ${jobId}`);

    return new Response(JSON.stringify({
      data: {
        jobId,
        status: 'completed',
        outputUrl
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Face swap processing error:', error);

    const errorResponse = {
      error: {
        code: 'FACE_SWAP_FAILED',
        message: error.message
      }
    };

    return new Response(JSON.stringify(errorResponse), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});

// Helper function to update job status
async function updateJobStatus(
  jobId: string, 
  status: string, 
  progress: number, 
  message: string, 
  serviceRoleKey: string, 
  supabaseUrl: string,
  errorMessage?: string
) {
  const updateData: any = {
    status,
    progress,
    updated_at: new Date().toISOString()
  };

  if (status === 'processing' && progress === 10) {
    updateData.processing_started_at = new Date().toISOString();
  }

  if (errorMessage) {
    updateData.error_message = errorMessage;
  }

  await fetch(`${supabaseUrl}/rest/v1/face_swap_jobs?id=eq.${jobId}`, {
    method: 'PATCH',
    headers: {
      'Authorization': `Bearer ${serviceRoleKey}`,
      'apikey': serviceRoleKey,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(updateData)
  });

  // Log the update
  await fetch(`${supabaseUrl}/rest/v1/processing_logs`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${serviceRoleKey}`,
      'apikey': serviceRoleKey,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      job_id: jobId,
      log_level: errorMessage ? 'error' : 'info',
      message: message,
      details: errorMessage ? { error: errorMessage } : { progress }
    })
  });
}

// Helper function to download files
async function downloadFile(url: string, filename: string): Promise<string> {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to download file: ${response.statusText}`);
  }

  const arrayBuffer = await response.arrayBuffer();
  const filePath = `/tmp/${filename}`;
  
  await Deno.writeFile(filePath, new Uint8Array(arrayBuffer));
  return filePath;
}

// Main Roop processing function
async function processWithRoop(
  sourceImagePath: string, 
  targetVideoPath: string, 
  outputPath: string, 
  jobId: string,
  serviceRoleKey: string,
  supabaseUrl: string
) {
  console.log('Starting Roop face swap processing...');
  
  // Install Roop if not already installed
  await installRoop();
  
  // Update progress
  await updateJobStatus(jobId, 'processing', 40, 'Analyzing source face...', serviceRoleKey, supabaseUrl);
  
  // Run Roop face swap command
  // Command: python run.py --source SOURCE_IMAGE --target TARGET_VIDEO --output OUTPUT_VIDEO --headless
  const roopCommand = [
    'python3',
    '/opt/roop/run.py',
    '--source', sourceImagePath,
    '--target', targetVideoPath,
    '--output', `/tmp/${outputPath}`,
    '--headless',
    '--execution-provider', 'cpu', // Use CPU for Edge Function compatibility
    '--frame-processor', 'face_swapper'
  ];
  
  console.log('Running Roop command:', roopCommand.join(' '));
  
  const process = new Deno.Command(roopCommand[0], {
    args: roopCommand.slice(1),
    stdout: 'piped',
    stderr: 'piped'
  });
  
  const child = process.spawn();
  
  // Monitor progress by reading stdout/stderr
  const decoder = new TextDecoder();
  let progress = 40;
  
  // Read output streams
  const readOutput = async () => {
    const reader = child.stdout.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      
      const output = decoder.decode(value);
      console.log('Roop output:', output);
      
      // Parse progress from output (Roop typically shows frame progress)
      const frameMatch = output.match(/Processing frame (\d+)\/(\d+)/);
      if (frameMatch) {
        const currentFrame = parseInt(frameMatch[1]);
        const totalFrames = parseInt(frameMatch[2]);
        progress = 40 + Math.round((currentFrame / totalFrames) * 40); // 40% to 80%
        
        await updateJobStatus(
          jobId, 
          'processing', 
          progress, 
          `Processing frame ${currentFrame}/${totalFrames}...`, 
          serviceRoleKey, 
          supabaseUrl
        );
      }
    }
  };
  
  const readErrors = async () => {
    const reader = child.stderr.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      
      const error = decoder.decode(value);
      console.log('Roop stderr:', error);
    }
  };
  
  // Start reading outputs
  Promise.all([readOutput(), readErrors()]);
  
  // Wait for process to complete
  const status = await child.status;
  
  if (!status.success) {
    throw new Error(`Roop processing failed with exit code: ${status.code}`);
  }
  
  await updateJobStatus(jobId, 'processing', 80, 'Face swap processing completed, finalizing...', serviceRoleKey, supabaseUrl);
  
  // Verify output file exists
  try {
    await Deno.stat(`/tmp/${outputPath}`);
    console.log('Output video created successfully');
  } catch (error) {
    throw new Error('Output video was not created');
  }
}

// Function to install Roop (run once per container)
async function installRoop() {
  try {
    // Check if Roop is already installed
    await Deno.stat('/opt/roop');
    console.log('Roop already installed');
    return;
  } catch {
    // Roop not installed, install it
    console.log('Installing Roop...');
    
    // Install Python dependencies
    const installCommands = [
      ['apt-get', 'update'],
      ['apt-get', 'install', '-y', 'python3', 'python3-pip', 'git', 'ffmpeg'],
      ['mkdir', '-p', '/opt'],
      ['git', 'clone', 'https://github.com/s0md3v/roop.git', '/opt/roop'],
      ['pip3', 'install', '-r', '/opt/roop/requirements.txt']
    ];
    
    for (const command of installCommands) {
      console.log('Running:', command.join(' '));
      const process = new Deno.Command(command[0], {
        args: command.slice(1),
        stdout: 'piped',
        stderr: 'piped'
      });
      
      const child = process.spawn();
      const status = await child.status;
      
      if (!status.success) {
        throw new Error(`Installation command failed: ${command.join(' ')}`);
      }
    }
    
    console.log('Roop installation completed');
  }
}

// Function to upload result video to Supabase Storage
async function uploadResultVideo(
  localPath: string, 
  jobId: string, 
  serviceRoleKey: string, 
  supabaseUrl: string
): Promise<string> {
  const fileName = `result_${jobId}_${Date.now()}.mp4`;
  const fileData = await Deno.readFile(`/tmp/${localPath}`);
  
  // Upload to Supabase Storage
  const uploadResponse = await fetch(`${supabaseUrl}/storage/v1/object/output-videos/${fileName}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${serviceRoleKey}`,
      'Content-Type': 'video/mp4',
      'x-upsert': 'true'
    },
    body: fileData
  });
  
  if (!uploadResponse.ok) {
    const errorText = await uploadResponse.text();
    throw new Error(`Failed to upload result video: ${errorText}`);
  }
  
  // Return public URL
  return `${supabaseUrl}/storage/v1/object/public/output-videos/${fileName}`;
}

// Function to cleanup temporary files
async function cleanupTempFiles(filePaths: string[]) {
  for (const filePath of filePaths) {
    try {
      await Deno.remove(filePath);
      console.log(`Cleaned up: ${filePath}`);
    } catch (error) {
      console.log(`Failed to cleanup ${filePath}:`, error.message);
    }
  }
}