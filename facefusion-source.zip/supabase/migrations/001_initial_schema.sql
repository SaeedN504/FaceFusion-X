-- FaceFusion Database Schema
-- This file contains the complete database schema for the FaceFusion application

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create face swap jobs table
CREATE TABLE IF NOT EXISTS face_swap_jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID,
    source_image_url TEXT NOT NULL,
    target_video_url TEXT NOT NULL,
    output_video_url TEXT,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'uploading', 'processing', 'completed', 'failed')),
    progress INTEGER DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    error_message TEXT,
    source_file_name TEXT,
    target_file_name TEXT,
    output_file_name TEXT,
    source_file_size BIGINT,
    target_file_size BIGINT,
    output_file_size BIGINT,
    processing_started_at TIMESTAMP WITH TIME ZONE,
    processing_completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create processing logs table
CREATE TABLE IF NOT EXISTS processing_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL,
    log_level TEXT NOT NULL DEFAULT 'info' CHECK (log_level IN ('info', 'warning', 'error', 'debug')),
    message TEXT NOT NULL,
    details JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create user profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
    id UUID PRIMARY KEY,
    email TEXT,
    full_name TEXT,
    avatar_url TEXT,
    total_jobs INTEGER DEFAULT 0,
    successful_jobs INTEGER DEFAULT 0,
    failed_jobs INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_face_swap_jobs_status ON face_swap_jobs(status);
CREATE INDEX IF NOT EXISTS idx_face_swap_jobs_user_id ON face_swap_jobs(user_id);
CREATE INDEX IF NOT EXISTS idx_face_swap_jobs_created_at ON face_swap_jobs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_processing_logs_job_id ON processing_logs(job_id);
CREATE INDEX IF NOT EXISTS idx_processing_logs_created_at ON processing_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_profiles_email ON user_profiles(email);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at columns
CREATE TRIGGER update_face_swap_jobs_updated_at BEFORE UPDATE ON face_swap_jobs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_profiles_updated_at BEFORE UPDATE ON user_profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security
ALTER TABLE face_swap_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE processing_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for face_swap_jobs
CREATE POLICY "Users can view their own jobs or anonymous jobs" ON face_swap_jobs
    FOR SELECT USING (user_id = auth.uid() OR user_id IS NULL);

CREATE POLICY "Users can create jobs" ON face_swap_jobs
    FOR INSERT WITH CHECK (user_id = auth.uid() OR user_id IS NULL);

CREATE POLICY "Users can update their own jobs" ON face_swap_jobs
    FOR UPDATE USING (user_id = auth.uid() OR user_id IS NULL);

CREATE POLICY "Users can delete their own jobs" ON face_swap_jobs
    FOR DELETE USING (user_id = auth.uid() OR user_id IS NULL);

-- Create RLS policies for processing_logs
CREATE POLICY "Users can view logs for their jobs" ON processing_logs
    FOR SELECT USING (
        job_id IN (
            SELECT id FROM face_swap_jobs 
            WHERE user_id = auth.uid() OR user_id IS NULL
        )
    );

CREATE POLICY "System can insert logs" ON processing_logs
    FOR INSERT WITH CHECK (true);

-- Create RLS policies for user_profiles
CREATE POLICY "Users can view their own profile" ON user_profiles
    FOR ALL USING (id = auth.uid());

-- Create function to clean up old jobs (optional)
CREATE OR REPLACE FUNCTION cleanup_old_jobs()
RETURNS void AS $$
BEGIN
    -- Delete jobs older than 30 days
    DELETE FROM face_swap_jobs 
    WHERE created_at < NOW() - INTERVAL '30 days';
    
    -- Delete orphaned logs
    DELETE FROM processing_logs 
    WHERE job_id NOT IN (SELECT id FROM face_swap_jobs);
END;
$$ LANGUAGE plpgsql;

-- Create function to update user statistics
CREATE OR REPLACE FUNCTION update_user_stats()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        -- Increment total jobs when a new job is created
        INSERT INTO user_profiles (id, total_jobs) 
        VALUES (NEW.user_id, 1)
        ON CONFLICT (id) 
        DO UPDATE SET total_jobs = user_profiles.total_jobs + 1;
        
        RETURN NEW;
    END IF;
    
    IF TG_OP = 'UPDATE' THEN
        -- Update success/failure counts when job status changes
        IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
            UPDATE user_profiles 
            SET successful_jobs = successful_jobs + 1
            WHERE id = NEW.user_id;
        END IF;
        
        IF NEW.status = 'failed' AND OLD.status != 'failed' THEN
            UPDATE user_profiles 
            SET failed_jobs = failed_jobs + 1
            WHERE id = NEW.user_id;
        END IF;
        
        RETURN NEW;
    END IF;
    
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for user statistics
CREATE TRIGGER trigger_update_user_stats
    AFTER INSERT OR UPDATE ON face_swap_jobs
    FOR EACH ROW
    WHEN (NEW.user_id IS NOT NULL)
    EXECUTE FUNCTION update_user_stats();

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT ALL ON TABLE face_swap_jobs TO anon, authenticated;
GRANT ALL ON TABLE processing_logs TO anon, authenticated;
GRANT ALL ON TABLE user_profiles TO anon, authenticated;

-- Insert sample data (optional, for testing)
-- Uncomment the following lines if you want sample data
/*
INSERT INTO face_swap_jobs (id, source_image_url, target_video_url, status, progress, source_file_name, target_file_name)
VALUES (
    uuid_generate_v4(),
    'https://example.com/sample-face.jpg',
    'https://example.com/sample-video.mp4',
    'completed',
    100,
    'sample-face.jpg',
    'sample-video.mp4'
);
*/